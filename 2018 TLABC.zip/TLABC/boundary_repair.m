function u = boundary_repair(v,low,up,str)

[NP, D] = size(v);   
u = v; 

if strcmp(str,'absorb')
    for i = 1:NP    
    for j = 1:D 
        if v(i,j) > up(j) 
            u(i,j) = up(j);
        elseif  v(i,j) < low(j)
            u(i,j) = low(j);
        else
            u(i,j) = v(i,j);
        end  
    end
    end   
end
   

if strcmp(str,'random')
    for i = 1:NP    
    for j = 1:D 
        if v(i,j) > up(j) || v(i,j) < low(j)
            u(i,j) = low(j) + rand*(up(j)-low(j));
        else
            u(i,j) = v(i,j);
        end  
    end
    end   
end


if strcmp(str,'reflect')
    for i = 1:NP
    for j = 1:D 
        if v(i,j) > up(j)
            u(i,j) = max( 2*up(j)-v(i,j), low(j) );
        elseif v(i,j) < low(j)
            u(i,j) = min( 2*low(j)-v(i,j), up(j) );
        else
            u(i,j) = v(i,j);
        end  
    end
    end   
end
