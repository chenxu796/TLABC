% Yao Xin benchmark

switch problem
      
     case 1 
            % lu: define the upper and lower bounds of the variables
             % Sphere model
            lu = [-100 * ones(1, D); 100 * ones(1, D)];

        case 2 
             % Schwefel's problem 2.22
            lu = [-10 * ones(1, D); 10 * ones(1, D)];

        case 3 
             % Schwefel's problem 1.2
            lu = [-100 * ones(1, D); 100 * ones(1, D)];
       
        case 4 
             % Schwefel's problem 2.21
            lu = [-100 * ones(1, D); 100 * ones(1, D)];

        case 5 
             % Generalized Rosenbrock��s functions 
            lu = [-30 * ones(1, D); 30 * ones(1, D)];
            
        case 6 
             % Step function
            lu = [-100 * ones(1, D); 100 * ones(1, D)];
         
        case 7 
             % Quartic function
            lu = [-1.28 * ones(1, D); 1.28 * ones(1, D)];
             
        case 8 
             % Generalized Schwefel��s problem 2.26
            lu = [-500 * ones(1, D); 500 * ones(1, D)];
   
        case 9 
             % Generalized Rastrigin��s function
            lu = [-5.12 * ones(1, D); 5.12 * ones(1, D)];
           
        case 10 
             % Ackley��s function
            lu = [-32 * ones(1, D); 32 * ones(1, D)];
          
        case 11 
             % Generalized Griewank function
            lu = [-600 * ones(1, D); 600 * ones(1, D)];
           
        case 12 
             % Generalized Penalized function 1
            lu = [-50 * ones(1, D); 50 * ones(1, D)];
          
        case 13 
             % Generalized Penalized function 2
            lu = [-50 * ones(1, D); 50 * ones(1, D)];
      
        
  end