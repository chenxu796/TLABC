function r = generateR(popsize, i) 

%  Generate index 
%  r = [r1 r2 r3 r4 r5]

r1 = randi(popsize);
while r1 == i
    r1 = randi(popsize); 
end
 
r2 = randi(popsize);
while r2 == r1 || r2 == i
    r2 = randi(popsize); 
end

r3 = randi(popsize);
while r3 == r2 || r3 == r1 || r3 == i
    r3 = randi(popsize); 
end

r4 = randi(popsize);
while r4 == r3 || r4 == r2 || r4 == r1 || r4 == i
    r4 = randi(popsize); 
end

r5 = randi(popsize);
while  r5 == r4 || r5 == r3 || r5 == r2 || r5 == r1 || r5 == i
    r5 = randi(popsize); 
end

r = [r1  r2  r3  r4  r5];

end

