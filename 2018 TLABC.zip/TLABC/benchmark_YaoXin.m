function f=benchmark_YaoXin(x,func_num)
 
% benchmark_YaoXin.m is the main function for 23 test functions, all minimize
% problems
% e.g. f=benchmark_func(x,func_num)
% x is the variable, f is the function value 
% func_num is the function num,

% Functions	Name
% f01	Sphere model
% f02	Schwefel��s problem 2.22
% f03	Schwefel��s problem 1.2
% f04	Schwefel��s problem 2.21
% f05	Generalized Rosenbrock��s functions
% f06	Step function
% f07	Quartic function
% f08	Generalized Schwefel��s problem 2.26
% f09	Generalized Rastrigin��s function
% f10	Ackley��s function
% f11	Generalized Griewank function
% f12	Generalized Penalized function 1
% f13	Generalized Penalized function 2

 
%Chen Xu  2014.Nov.15

if func_num==1  % Sphere model
    [ps,D]=size(x); 
    f=sum(x.^2,2);
end

if func_num==2  % Schwefel��s problem 2.22
    [ps,D]=size(x);
    f=sum(abs(x),2)+prod(abs(x),2); 
end

if func_num==3  % Schwefel��s problem 1.2
    [ps,D]=size(x);
    for k=1:ps
        temp=cumsum(x(k,:));
        temp=temp.^2;
        f(k,:)=sum(temp); 
    end
end

if func_num==4  % Schwefel��s problem 2.21
    [ps,D]=size(x);
    for k=1:ps
        temp=abs(x(k,:));
        f(k,:)=max(temp); 
    end
end

if func_num==5  % Generalized Rosenbrock��s functions
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        for i=1:D-1
            f(k,:)=f(k,:)+100*(x(k,i+1)-x(k,i)^2)^2+(1-x(k,i))^2; 
        end
    end
end

if func_num==6  % Step Function
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        temp = floor(x+0.5);
        f=sum(temp.^2,2);
    end
end

if func_num==7  % Quartic Function i.e. Niose
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        for i=1:D
            f(k,:)=f(k,:)+i*x(k,i)^4; 
        end
        f(k,:)=f(k,:)+rand;
    end
end

if func_num==8  % Generalized Schwefel's Problem 2.26
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        for i=1:D
            f(k,:)=f(k,:)-x(k,i)*sin(sqrt(abs(x(k,i)))); 
        end
    end
end

if func_num==9  % Generalized Rastrigin's Function
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        for i=1:D
            f(k,:)=f(k,:)+x(k,i)^2-10*cos(2*pi*x(k,i))+10; 
        end
    end
end

if func_num==10  % Ackley's Function
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        temp1=(sum(x(k,:).^2))/D;
        temp1=-20*exp(-0.2*sqrt(temp1));
        temp2=sum(cos(2*pi*x(k,:)))/D;
        temp2=-exp(temp2); 
        f(k,:)=f(k,:)+temp1+20+temp2+exp(1); 
    end
end

if func_num==11  % Generalized Griewank Function
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=sum(x(k,:).^2)/4000-prod(cos(x(k,:)./(sqrt([1:D]))))+1; 
    end
end

if func_num==12  % Generalized Penalized Function 1
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        y(k,:)=1+(x(k,:)+1)./4;
        temp1=0;
        for i=1:D-1
            temp1=temp1+(y(k,i)-1)^2*(1+10*(sin(pi*y(k,i+1)))^2);
        end
        temp1=temp1+10*(sin(pi*y(k,1)))^2+(y(k,D)-1)^2;
        temp1=temp1*pi/D;
        temp2=0;
        for i=1:D
            temp2=temp2+u12(x(k,i),10,100,4);
        end
        f(k,:)=f(k,:)+temp1+temp2;
    end
end

if func_num==13  % Generalized Penalized Function 2
    [ps,D]=size(x);
    for k=1:ps
        f(k,:)=0;
        temp1=0;
        for i=1:D-1
            temp1=temp1+(x(k,i)-1)^2*(1+(sin(3*pi*x(k,i+1)))^2);
        end
        temp1=temp1+(sin(3*pi*x(k,1)))^2+(x(k,D)-1)^2;
        temp1=temp1*0.1;
        temp2=0;
        for i=1:D
            temp2=temp2+u12(x(k,i),5,100,4);
        end
        f(k,:)=f(k,:)+temp1+temp2;
    end
end

end


function u=u12(x,a,k,m)
% ����f12: Generalized Penalized Function
if x>a
    u=k*(x-a)^m; 
elseif x>=-a & x<=a
    u=0;
elseif x<a
    u=k*(-x-a)^m;
end  
end

 
 
 