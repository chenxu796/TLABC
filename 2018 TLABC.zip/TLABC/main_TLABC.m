
%************************************************************************************************** 
%  Teaching-learning-based artificial bee colony
%  Writer: Chen Xu
%  Date: 2017/09/15
%**************************************************************************************************


clc;
clear all;  
format long; 

fun = @benchmark_YaoXin; 

for problem = 1
    
    Number = 1;
    runNumber = 1;  % The total number of runs 
    
    
    while Number <= runNumber

        rand('seed', sum(100 * clock)); 
        tic

        D = 30;
        problem_range; 
        Xmin = lu(1,:);
        Xmax = lu(2,:);

        popsize = 50;               
        trial=zeros(1,popsize);  
        limit = 200;
        CR = 0.5;
        
        % Initialize the main population
        X = repmat(Xmin, popsize, 1) + rand(popsize, D) .* (repmat(Xmax-Xmin, popsize, 1));
        val_X = fun(X,problem);  
        [val_gBest,min_index] = min(val_X); 
        gBest = X(min_index(1),:);
                
        FES = popsize; maxFES = D*10000;       
        outcome =  val_gBest*ones(popsize,1) ;

        while   FES < maxFES

            % == == == == == =  Teaching-based employed bee phase  == == == == == = 
            for i=1:popsize 
                [~,sortIndex] = sort(val_X);
                mean_result = mean(X);        % Calculate the mean
                Best = X(sortIndex(1),:);     % Identify the teacher   
                TF=round(1+rand*(1));
                Xi = X(i,:) + (Best -TF*mean_result).*rand(1,D); 
                % Diversity learning
                r = generateR(popsize, i);
                F = rand; 
                V = X(r(1),:) + F*(X(r(2),:) - X(r(3),:));
                flag = (rand(1,D)<=CR);
                Xi(flag) = V(flag);  
                Xi = boundary_repair(Xi,Xmin,Xmax,'reflect'); 
                % Accept or Reject 
                val_Xi = fun(Xi,problem); FES = FES+1;
                if val_Xi<val_X(i,:)
                    val_X(i,:) = val_Xi; X(i,:) = Xi;
                    trial(i) = 0;
                else
                    trial(i) = trial(i)+1; 
                end 
            end
            
            % == == == == == =  Learning-based onlooker bee phase== == == == == =
            Fitness = calculateFitness(val_X); 
            prob = Fitness/sum(Fitness);  
            cum_prob = cumsum(prob); 
            for k=1:popsize  
                i = find(rand<cum_prob,1); 
                j = randi(popsize);
                while j==i,j=randi(popsize); end
                if val_X(i,:)<val_X(j,:)
                    Xi = X(i,:) + rand(1,D).*(X(i,:)-X(j,:));
                else
                    Xi = X(i,:) + rand(1,D).*(X(j,:)-X(i,:));
                end  
                Xi = boundary_repair(Xi,Xmin,Xmax,'reflect'); 
                %  Accept or Reject 
                val_Xi = fun(Xi,problem);  FES = FES+1;
                if  val_Xi<val_X(i,:)
                    val_X(i,:) = val_Xi; X(i,:) = Xi;
                end 
                
            end  
            
            % == == == == == = Generalized oppositional scout bee phase  == == == == == =
            ind = find(trial==max(trial));
            ind = ind(1);
            if (trial(ind)>limit)
                trial(ind) = 0;
                sol = (Xmax-Xmin).*rand(1,D)+Xmin;
                solGOBL = (max(X)+min(X))*rand-X(ind,:);
                sol = [sol;solGOBL];
                sol = boundary_repair(sol,Xmin,Xmax,'random');
                val_sol = fun(sol,problem);
                FES = FES+2;
                [~,min_index] = min(val_sol);
                X(ind,:) = sol(min_index(1),:);
                val_X(ind,:) = val_sol(min_index(1),:); 
            end;   
            
            % The best food source is memorized  
            if min(val_X)<val_gBest
                [val_gBest,min_index] = min(val_X); 
                gBest = X(min_index(1),:);
            end 
 
            FES0 = length(outcome);
            outcome = [outcome; val_gBest*ones((FES-FES0),1)];   
           
            if mod(FES,1e4)<101  
                disp(sprintf('problem=%d;  Number=%d;  FES=%d;  val_gBest=%d;',problem,Number,FES,val_gBest)); 
            end
                        
        end  
  
        disp(sprintf('problem=%d;  Number=%d;  FES=%d;  val_gBest=%d;   runtime=%d',problem,Number,FES,val_gBest,toc)); 

        %  record data
        eval(['record.outcome',num2str(Number),'=','outcome',';']);
        record.time(Number) = toc;  
        record.FES(Number) = FES;

        Number = Number + 1;  
        
    end

    %   save data
    filename = strcat('out_YaoXin_D',num2str(D),'_f', num2str(problem),'_TLABC');   
    save(filename, 'record');

end
 
 
     